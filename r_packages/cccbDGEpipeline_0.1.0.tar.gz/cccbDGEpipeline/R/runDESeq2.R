# Hello, world!
#
# This is an example function named 'hello'
# which prints 'Hello, world!'.
#
# You can learn more about package authoring with RStudio at:
#
#   http://r-pkgs.had.co.nz/
#
# Some useful keyboard shortcuts for package authoring:
#
#   Build and Reload Package:  'Cmd + Shift + B'
#   Check Package:             'Cmd + Shift + E'
#   Test Package:              'Cmd + Shift + T'

runDESeq2<-function(count_data=NA, annotations=NA, FORMULA=NA){
  # need to check for formula on annotations
  # need to check for annotations table contain Sample_ID column
  #
  COND_FEATURE=gsub("\\~([[:alnum:]_]+)", "\\1", FORMULA)

  count_data<-round(count_data) # ensure only integer is used into deseq
  annotations.f=annotations[annotations$Sample_ID %in% colnames(count_data),]  # consider only

  # in case the count matrix has more columns than the annotations:
  count_data <- count_data[,annotations$Sample_ID]

  dds <- DESeqDataSetFromMatrix(countData = count_data,
                              colData = annotations.f,
                              design = as.formula(FORMULA))
  dds <- DESeq(dds)
  nc <- counts(dds, normalized = T)
  #write.table(nc, paste0(curr_outdir, "/", srna_type,'_normalized_counts.tsv'), sep='\t')

  result=list()
  comparisonNameList = c()
  for(i in 1:(length(levels(annotations.f[[COND_FEATURE]]))-1)){
    for(j in (i+1):length(levels(annotations.f[[COND_FEATURE]]))){
      condA=levels(annotations.f[[COND_FEATURE]])[i]
      condB=levels(annotations.f[[COND_FEATURE]])[j]
      res <- results(dds, contrast=c(COND_FEATURE, condA, condB))
      resOrdered <- res[order(res$pvalue),]
      resOrdered <- cbind.data.frame(feature=rownames(resOrdered), resOrdered)
      comparisonName <- paste0(condA,"_", condB)
      comparisonNameList <- c(comparisonNameList, comparisonName)
      result[[comparisonName]]=resOrdered
    }
  }
  return(list(dge=result, norm.mtx=nc, comparisons=comparisonNameList))
}
