Draw.PCA<-function(dge_result=NA,
                   outfile=NA,
                   res=200,
                   width=12,
                   height=12){

  # Make PCA on normalized count
  dge_result[["pca"]]=round(prcomp(t(dge_result$norm.mtx))$x)
  dge_result$pca=cbind(Sample_ID=rownames(dge_result$pca),dge_result$pca)
  curr_pca_mtx=merge(dge_result$pca, annotations, by="Sample_ID")

  pca_plot<-ggplot(curr_pca_mtx, aes(x=PC1, y=PC2, color=Group, label=Sample_ID))+geom_point(size=2)
  pca_plot+geom_text(aes(label=Sample_ID), size=3, hjust=1, vjust=-2)
  pca_plot+stat_ellipse()

  if(!(is.na(outfile))){
    ggsave(outfile, plot = pca_plot,
         width = width, height = height, unit="in",
         dpi = res, limitsize = TRUE, device="pdf")
  }
}
